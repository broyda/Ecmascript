import { Component, ElementRef } from '@angular/core';
import { Http } from "@angular/http";
import { Router } from '@angular/router';

import { ToastsManager } from 'ng2-toastr/ng2-toastr';


import { bpmn } from './../modeler/bpmnBase';
import { ModelerService } from "./../modeler/modeler.service";
import { AppComponent } from "../app.component";

@Component({
    selector: 'front-page',
    templateUrl: './front-page.component.html',
    styleUrls: ['./front-page.component.css'],
    //       host: {
    //     '(document:click)': 'onClick($event)',
    //   },
})
export class FrontPageComponent {
    title: string = 'Angular 2 with BPMN-JS';
    AvailableBpmns: bpmn[];
    showDeleteBtn: boolean;
    uniqueProdcut: any[];
    mySetTree: any = new Set();
    selectedProduct: any;

    constructor(private http: Http,
        private modelerService: ModelerService,
        private router: Router,
        private _eref: ElementRef,
        private toastr: ToastsManager
    ) {
        this.getBpmn();
    }
    onInit() {
        this.showDeleteBtn = false;
    }
    // Available bpmn from service
    getBpmn(): void {
        this.modelerService.getAllBpmn().then((response) => {
            this.AvailableBpmns = JSON.parse(response._body);
        }
        );
    }

    setNavigation(id: any) {
        this.router.navigate(['/modeler', id === undefined ? 0 : id]);
    }

    deleteBPMN(id: any) {

        console.log(id);
        this.modelerService.deleteBpmn(id).then(
            (response) => {
                if (response.status == "200") {
                    this.getBpmn();
                    this.toastr.success(null, 'BPMN deleted successfully.');
                } else {
                    alert('Deleted unsuccessful');
                }

            }


        )

    }

    toggleDelete($event: any, bpmns: any) {
        console.log('event-->', $event);
        console.log('position-->', $event.target.tabIndex);
        alert('inside delete');
        console.log('avail -->', bpmns);
    }

    uniqueProducts() {

        let currencies = this.AvailableBpmns.filter((x, i, a) => {
            this.mySetTree.add(x.modelAssociation);
            // x && a.indexOf(x) === i;
            // console.log('x', x);
            // console.log('i', i);
            // console.log('a', a);
        });
        console.log(this.mySetTree);

    }
    generateDSL(product: any) {
        let productList: any[] = [];
        // console.log(product);
        this.AvailableBpmns.filter((x) => {
            // console.log(x.modelAssociation);
            if (x.modelAssociation == product) {
                productList.push(x.id);
            }
        });

        this.modelerService.generateDSL(productList).then(response => {

            const ErrorMsg = ' DSL generation unsuccessful';
            console.log('dsl respionse=-->', response)

            if (response.status == "200") {

                const SuccessMsg = ' DSL generation successful';

                this.toastr.success(
                    '<a style="color: blue" target="_blank" href=' + AppComponent.GET_SERVER_URL + '/bpmnXmlDownload>Download generated DSL </a>',
                    SuccessMsg,
                    {
                        enableHTML: true,
                        toastLife: 20000
                    });

            } else {
                this.toastr.error(
                    ErrorMsg, 'Oops!');
            }


            //     if (response.status == '200')
            //         alert("Generate DSL sucessfull");
            //     else
            //         alert("Generate DSL unsucessfull");
        });
        //  console.log(productList);
    }


    //   onClick(event:any) {
    //    if (!this._eref.nativeElement.contains(event.target)) // or some similar check
    //     alert('hit !');
    //   }
}
