// import {NodeProps} from './NodePropsBase';

export const NodePropsModdle = {
  "name": "Magic",
  "prefix": "magic",
  "uri": "http://magic",
  "xml": {
    "tagAlias": "lowerCase"
  },
  "associations": new Array(),
  "types": [
    {
      "name": "BewitchedStartEvent",
      "extends": [
        "bpmn:BaseElement"
      ],
      "properties": [
        {
          "name": "activity_name",
          "isAttr": true,
          "type": "String"
        },
        {
          "name": "activity_des",
          "isAttr": true,
          "type": "String"
        },
        {
          "name": "handler_name",
          "isAttr": true,
          "type": "String"
        },
        {
          "name": "handler_api_name",
          "isAttr": true,
          "type": "String"
        },
      ]
    },
  ]
}