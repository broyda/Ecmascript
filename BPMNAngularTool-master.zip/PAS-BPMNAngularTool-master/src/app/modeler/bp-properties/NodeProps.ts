'use strict';

var entryFactory = require('bpmn-js-properties-panel/lib/factory/EntryFactory');

var is = require('bpmn-js/lib/util/ModelUtil').is;

export function nodeProps(group: any, element: any) {

  // Only return an entry, if the currently selected
  // element is a start event.

  // console.log(element);

  if (

    // is(element, 'bpmn:StartEvent') ||
    // is(element, 'bpmn:EndEvent') ||

    is(element, 'bpmn:UserTask') ||
    is(element, 'bpmn:SendTask') ||
    is(element, 'bpmn:ScriptTask') ||
    is(element, 'bpmn:Gateway') ||
    is(element, 'bpmn:Task')


  ) {
    group.entries.push(entryFactory.textField({
      id: 'activity_name',
      description: 'Enter Capability Name ',
      label: 'Capability Name',
      modelProperty: 'activity_name'
    }));

    group.entries.push(entryFactory.textField({
      id: 'activity_des',
      description: 'Enter Capability description ',
      label: 'Capability description ',
      modelProperty: 'activity_des',
      // selectOptions: [{ name: 'name1', value: 'value1' },
      // { name: 'name2', value: 'value2' }]

    }));

    group.entries.push(entryFactory.textField({
      id: 'handler_name',
      description: 'Enter Handler Name ',
      label: 'Handler Name ',
      modelProperty: 'handler_name'
    }));

    group.entries.push(entryFactory.textField({
      id: 'handler_api_name',
      description: 'Enter Handler API Name ',
      label: 'Handler API Name ',
      modelProperty: 'handler_api_name'
    }));

  }

  if (is(element, 'bpmn:EndEvent')) {

  }

  if (is(element, 'bpmn:ExclusiveGateway')) {

  }

  //Task
  if (is(element, 'bpmn:Task')) {

  }

};