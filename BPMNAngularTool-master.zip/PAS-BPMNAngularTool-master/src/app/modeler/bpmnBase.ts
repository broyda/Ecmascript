export class bpmn {
    id: any;
    name: any;
    description: any;
    bpAPIId: any
    bpmnXml: any;
    bpmnUri: any;
    businessAPIName: any;
    operName: any;
    modelAssociation:any

}
