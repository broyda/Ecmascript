import { Component, OnInit } from '@angular/core';
import { Http } from "@angular/http";
import { ActivatedRoute, Router } from '@angular/router';

import { PaletteProvider } from './palette';
import { CustomPropertiesProvider } from './props-provider';
import { BPMNStore, Link } from "../bpmn-store/bpmn-store.service";

import { bpmn } from './bpmnBase';
import { ModelerService } from "./modeler.service";

const modeler = require("bpmn-js/lib/Modeler.js");
const propertiesPanelModule = require('bpmn-js-properties-panel');
const propertiesProviderModule = require('bpmn-js-properties-panel/lib/provider/bpmn');

import { CustomModdle } from './custom-moddle';
import { Observable, Subject } from "rxjs";

import { NodePropsModdle } from './bp-properties/Node-moddle';

import { ToastsManager } from 'ng2-toastr/ng2-toastr';

const customPaletteModule = {
    paletteProvider: ['type', PaletteProvider]
};
const customPropertiesProviderModule = {
    __init__: ['propertiesProvider'],
    propertiesProvider: ['type', CustomPropertiesProvider]
};

const containerRef = '#js-canvas';
const propsPanelRef = '#js-properties-panel';

const initalBPMN =
    '<?xml version="1.0" encoding="UTF-8"?><bpmn:definitions xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" targetNamespace="http://bpmn.io/schema/bpmn" id="Definitions_1"><bpmn:process id="Process_1" isExecutable="false"><bpmn:startEvent id="StartEvent_1"/></bpmn:process><bpmndi:BPMNDiagram id="BPMNDiagram_1"><bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1"><bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1"><dc:Bounds height="36.0" width="36.0" x="173.0" y="102.0"/></bpmndi:BPMNShape></bpmndi:BPMNPlane></bpmndi:BPMNDiagram></bpmn:definitions>';

@Component({
    templateUrl: './modeler.component.html',
    styleUrls: ['./modeler.component.css'],
    providers: [BPMNStore]
})
export class ModelerComponent implements OnInit {
    //1st tab props
    showBpDetailsTab: boolean;
    isAddEntity: boolean;

    //2nd tab props
    modeler: any;
    bpmnObject: bpmn;
    selectedBPMN: any;
    AvailableBpmns: bpmn[];

    url: string;
    _urls: Link[];
    extraPaletteEntries: any;
    commandQueue: Subject<any>;

    BusinessServiceResponse: any;
    BusinessAPI: any;
    businessAPINameList: any[] = [];
    modelAssociated: any;
    businessAPIName: any;
    operList: any[] = [];
    BusinessApiObj: any;
    finalUri: any;

    constructor(private http: Http,
        private store: BPMNStore,
        private modelerService: ModelerService,
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private toastr: ToastsManager

    ) {
        this.getAllBusiness();
    }

    get urls(): Link[] {
        return this._urls;
    }

    set urls(u: Link[]) {
        console.log("urls: ", u);
        this._urls = u;
        this.url = u[0].href;
    }


    manageBpmnObject(id: any) {
        // id = '59b0ecbb0cc4b523ccc6b4b5';
        this.bpmnObject = {
            id: '',
            name: '',
            description: '',
            bpAPIId: '',
            bpmnXml: '',
            bpmnUri: '',
            businessAPIName: '',
            operName: '',
            modelAssociation: ''
        }
        if (id) {
            if (id === '0') {
                this.bpmnObject = {
                    id: null,
                    name: '',
                    description: '',
                    bpAPIId: '',
                    bpmnXml: '',
                    bpmnUri: '',
                    businessAPIName: '',
                    operName: '',
                    modelAssociation: ''
                }
                this.isAddEntity = true;
                this.setBPMNxml();
            } else if (id !== '0') {
                this.modelerService.getBpmn(id)
                    .then((response) => {
                        // alert(JSON.parse(response._body));
                        console.log("edit resp:", response)
                        this.bpmnObject = response;
                        this.setBPMNxml();
                    });
            }
            // console.log(this.bpmnObject);
        }
    }

    ngOnInit() {


        //this.getAllBusiness();

        const url = window.location.href;
        let urlArray: any[] = url.split("/");
        // alert(urlArray[4])

        const id = urlArray[4];

        this.manageBpmnObject(id);

        this.showBpDetailsTab = true;
        //  this.canvasFlag = false;
        // this.getBpmn();

        // this.commandQueue = new Subject();

        // this.commandQueue
        //     .subscribe(cmd => console.log('Received command: ', cmd));

        // this.commandQueue
        //     .filter(cmd => 'extra' == cmd.action)
        //     .subscribe(cmd => console.log('Received SUPER SPECIAL EXTRA command: ', cmd));


        // this.commandQueue
        //     .filter(cmd => 'save' == cmd.action)
        //     .do(cmd => console.log('Received SUPER SPECIAL SAVE command: ', cmd))
        //     .subscribe(() => this.modeler.saveXML((err: any, xml: any) => {
        //         console.log('xml!?!', err, xml)
        //         if (xml) {

        //             this.modelerService.saveBPMN(this.bpmnObject);
        //         }
        //     })
        //     );


        // this.store.listDiagrams()
        //     .do(links => this.urls = links)
        //     .do(() => console.log('Got links: ', this.urls))
        //     .flatMap(() => this.store.paletteEntries())
        //     .do(entries => this.extraPaletteEntries = entries)
        //     .do(() => console.log('Got entries: ', this.extraPaletteEntries))
        //     .subscribe(() => this.createModeler());

        //this.loadExisitngBPMN(initalBPMN);


    }

    getAllBusiness() {
        this.modelerService.getAllBusiness().then((response) => {
            this.BusinessServiceResponse = JSON.parse(response._body);
            this.BusinessAPIList(this.BusinessServiceResponse);
            this.onLoad();
        }
        );
    }

    BusinessAPIList(BusinessResponse: any) {
        // this.BusinessAPI

        let baseUri: any;

        this.businessAPINameList = [];
        this.businessAPIName = "";


        console.log('BusinessResponse-->', BusinessResponse);


        for (let i = 0; i < BusinessResponse.length; i++) {

            let businessActivityJson = JSON.parse(BusinessResponse[i].businessComposerJson);
            console.log('businessActivityJson-->', businessActivityJson);


            this.businessAPIName = BusinessResponse[i].name;
            // console.log('BusinessResponse-->', BusinessResponse[i].name);

            baseUri = businessActivityJson.baseUri;
            console.log('baseUri-->', baseUri);


            for (let j = 0; j < businessActivityJson.activities.operation.length; j++) {
                console.log('operations-->', businessActivityJson.activities.operation[j].operationName);

                console.log('BusinessResponse[i]-->', BusinessResponse[i]);

                this.businessAPINameList.push({
                    bList: this.businessAPIName + ' | ' + businessActivityJson.activities.operation[j].operationName,
                    bpmnUri: baseUri + businessActivityJson.activities.operation[j].uri,
                    baseUri: baseUri,
                    bussinessResponse: BusinessResponse[i]
                });
            }
        }

        console.log('businessAPINameList-->', this.businessAPINameList);

    }
    setBPMNxml() {
        const url = window.location.href;
        let urlArray: any[] = url.split("/");
        // alert(urlArray[4])

        const id = urlArray[4];
        this.createModeler();

        if (id === '0') {
            this.selectedBPMN = initalBPMN;
        }
        else if (id !== '0') {
            console.log("bpmnObject", this.bpmnObject);
            this.selectedBPMN = this.bpmnObject.bpmnXml;
        }

        console.log(this.selectedBPMN);

        this.loadExisitngBPMN();

    }


    onSelect(event: any) {
        console.log('onSelect-->', event);
        console.log('event-->', );

        let operObj: any;

        this.BusinessServiceResponse.filter((item: any) => {

            let itemJson = JSON.parse(item.businessComposerJson);
            operObj = itemJson.activities.operation;

            console.log('operationName-->', operObj[0].operationName)
            if (operObj[0].operationName == event.target.value) {
                this.bpmnObject.bpmnUri = this.bpmnObject.bpmnUri + operObj[0].uri;
            }

            for (let i = 0; i < operObj.length; i++) {
                this.operList.push(operObj[i].operationName);
            }

        });


        console.log(' this.bpmnObject.bpmnUri-->', this.bpmnObject.bpmnUri);

        //  bpmnUri
        //   this.modelAssociation
    }

    onLoad() {
        let operObj: any;

        this.BusinessServiceResponse.filter((item: any) => {

            let itemJson = JSON.parse(item.businessComposerJson);
            operObj = itemJson.activities.operation;

            for (let i = 0; i < operObj.length; i++) {
                this.operList.push(operObj[i].operationName);
            }

        });
    }

    onApiChange(event: any) {
        console.log('API id-->', event.target.value);

        //     for (let i = 0; i < this.BusinessServiceResponse.length; i++) {
        //         if (this.BusinessServiceResponse[i].id)
        //    }

        let operObj: any;
        this.operList = [];
        // this.BusinessApiObj = "";
        let temp: any;
        this.BusinessApiObj = this.BusinessServiceResponse.filter((item: any) => {




            if (item.name == event.target.value) {
                this.bpmnObject.businessAPIName = item.name;
                temp = item;

                console.log('item--->', item)
                let itemJson = JSON.parse(item.businessComposerJson);
                operObj = itemJson.activities.operation;
                this.bpmnObject.bpmnUri = itemJson.baseUri;
            }
        }
        );

        for (let i = 0; i < operObj.length; i++) {
            this.operList.push(operObj[i].operationName);
        }


        // this.BusinessApiObj = temp;
        this.bpmnObject.modelAssociation = temp.modelAssociated;
        console.log('BusinessApiObj--->', this.BusinessApiObj)
        console.log('temp--->', temp)
        console.log('finalUri--->', this.finalUri)

    }




    saveModeler() {

        this.modeler.saveXML((err: any, xml: any) => {
            console.log('xml!?!', err, xml)
            if (xml) {
                this.bpmnObject = {
                    id: this.bpmnObject.id,
                    name: this.bpmnObject.name,
                    description: this.bpmnObject.description,
                    bpAPIId: this.bpmnObject.bpAPIId,
                    bpmnXml: xml,
                    bpmnUri: this.bpmnObject.bpmnUri,
                    businessAPIName: this.bpmnObject.businessAPIName,
                    operName: this.bpmnObject.operName,
                    modelAssociation: this.bpmnObject.modelAssociation

                }
                this.modelerService.saveBPMN(this.bpmnObject).then(
                    (response) => {
                        // //alert(response.status)
                        // if (response.status == '200')
                        //     // alert("Deleted successfully")
                        //     this.router.navigate(['/front-page']);
                        // else
                        //     alert("Save unsuccessful")


                        if (response.status == "200") {

                            const addMsg = ' BPMN added successfully';
                            const updateMsg = ' BPMN updated successfully';

                            if (this.isAddEntity === true) {
                                this.toastr.success(null,
                                    '\'' + this.bpmnObject.name + '\'' + addMsg);
                            } else {
                                this.toastr.success(null,
                                    '\'' + this.bpmnObject.name + '\'' + updateMsg);
                            }

                            // navigating to home page
                            this.router.navigate(['/front-page']);

                        } else {
                            this.toastr.error(
                                '\'' + this.bpmnObject.name + '\'' + 'BPMN save unsuccessfull', 'Oops!');
                        }
                    }
                );

            }
        })
    }

    EditModeler() {

    }
    createModeler() {

        //   console.log('Creating modeler, injecting extraPaletteEntries: ', this.extraPaletteEntries);
        this.modeler = new modeler({
            container: containerRef,
            propertiesPanel: {
                parent: propsPanelRef
            },
            additionalModules: [
                { 'extraPaletteEntries': ['type', () => this.extraPaletteEntries] },
                { 'commandQueue': ['type', () => this.commandQueue] },
                propertiesPanelModule,
                propertiesProviderModule,
                customPropertiesProviderModule,
                customPaletteModule,
            ],
            moddleExtensions: {
                ne: CustomModdle,
                magic: NodePropsModdle

            },
        });



    }

    loadBPMN() {
        alert("load bpmn starts")
        // this.createModeler();
        // Start with an empty diagram:
        // this.url = this.urls[0].href;
        this.url = '/diagrams/initial.bpmn';
        console.log('load', this.url, this.store);
        var canvas = this.modeler.get('canvas');
        this.http.get(this.url)
            .map(response => response.text()
            )
            .map(data => {
                this.modeler.importXML(data, this.handleError)
                console.log(data);
            })
            .subscribe(x => x ? this.handleError(x) : this.postLoad())
            ;
    }


    loadExisitngBPMN() {

        console.log("importBPMN", this.selectedBPMN)
        var canvas = this.modeler.get('canvas');
        this.modeler.importXML(this.selectedBPMN, this.handleError)
    }

    postLoad() {
        var canvas = this.modeler.get('canvas');
        canvas.zoom('fit-viewport');
    }

    handleError(err: any) {
        if (err)
            console.log('error rendering', err);
    }





    // Available bpmn from service
    getBpmn(): void {
        // this.AvailableBpmns = this.modelerService.getAllBpmn();

        // this.modelerService.getAllBpmn().then((response) => {
        //     this.AvailableBpmns = JSON.parse(response._body);
        // }
        // );

    }
}

