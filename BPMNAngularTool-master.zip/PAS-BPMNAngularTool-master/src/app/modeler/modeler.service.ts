import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Headers } from '@angular/http';
import { Observable } from "rxjs";

import { bpmn } from './bpmnBase';
import { BPMNS } from './mock-bpmn';
import { AppComponent} from '../app.component';

@Injectable()
export class ModelerService {

    constructor(private http: Http) { }

    private baseUrl = AppComponent.GET_SERVER_URL;
    private headers = new Headers({ 'Content-Type': 'application/json' });


    private handleError(error: Promise<any>): Promise<any> {
        console.error('An error occured', error);
        // console.log('ERROR CATCH: Get ConfiguratorService is unavialble');
        return Promise.reject(error);
    }

    public saveBPMN(data: any): Promise<any> {
        const url = this.baseUrl + '/bpmn';
        // console.log(url);
        // console.log(JSON.stringify(data));
        // return null;
        console.log("service 1", JSON.stringify(data));
        console.log("service 2", data);

        return this.http
            .post(url, data, { headers: this.headers })
            .toPromise()
            .then((response) => response)
            .catch(this.handleError);
    }

    public getAllBpmn(): Promise<any> {
        const url = this.baseUrl + '/bpmn';

        //return BPMNS;
        return this.http
            .get(url)
            .toPromise()
            .then((respone) => respone)
            .catch(this.handleError);
    }


    public getBpmn(id: any): Promise<any> {
        const url = this.baseUrl + '/bpmn/' + id;
        // return BPMNS[id].bpmnXml;

        return this.http
            .get(url)
            .toPromise()
            .then((respone) => respone.json())
            .catch(this.handleError);

    }

     public deleteBpmn(id: any): Promise<any> {
        const url = this.baseUrl + '/bpmn/' + id;
        // return BPMNS[id].bpmnXml;
        return this.http
            .delete(url)
            .toPromise()
            .then(respone => respone)
            .catch(this.handleError);

    }

     public getAllBusiness(): Promise<any> {
        const url = this.baseUrl + '/businessAPI';

        //return BPMNS;
        return this.http
            .get(url)
            .toPromise()
            .then((respone) => respone)
            .catch(this.handleError);
    }

    generateDSL(data: any): Promise<any> {
    console.log('data-->',data);
    const url = this.baseUrl + '/bpmnParser';
    return this.http
      .post(url, data, { headers: this.headers })
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
}
