import { Component, ViewContainerRef } from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';

@Component({
    selector: 'my-app',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent  {

  
  //  offshore nijin's machine- http://mngnet358520d
  // offshore server machine- http://mngnet367236d

  public static GET_SERVER_URL = 'http://mngnet367236d:9091/product/v1/services/';

  public viewContainerRef: ViewContainerRef;

  constructor(public toastr: ToastsManager, vRef: ViewContainerRef) {
    this.viewContainerRef = vRef;
    this.toastr.setRootViewContainerRef(vRef);
  }


}
