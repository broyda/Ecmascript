BPMN-JS Tool
 
Setup / Installation
---

- `npm install`
- `npm start` to start dev-server on localhost:8080
- `npm run build` to build distribution into `dist` directory.  

